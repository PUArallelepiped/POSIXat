# OS Team Project 1

### Team Member
- 110590001 郭丞軒
- 110590002 王熯竑
- 110590049 藍振耘
- 110590450 歐佳昀

### Division of Labor
0.25 for each member, all members are responsible for writing the code and report.
